defmodule AlnaslWeb.JoinController do
  @moduledoc """
  `/join/<code>`: the one link a bridge needs (`Alnasl.Bridges`).

  `POST` is the bridge redeeming it - who it is in, its own key out, as
  JSON. A used, expired or unknown code is a 410 and nothing more; a bridge
  that speaks another version of the link is a 409, one that is still in
  another hall a 403. `GET` is somebody who
  scanned the code with a phone instead of the bridge: a page that says
  where it goes.
  """

  use AlnaslWeb, :controller

  alias Alnasl.Bridges

  def redeem(conn, %{"code" => code} = params) do
    identity = Map.take(params, ["v", "bridge", "name", "software"])

    case Bridges.redeem(code, identity) do
      {:ok, %{key: key}} ->
        json(conn, %{
          key: key,
          socket: "/bridge/link",
          server: Bridges.server_name(),
          # Whoever could show the link was the hall's owner (or the box
          # had no accounts): that one may make the bridge forget its boards.
          owner: true
        })

      {:error, :version} ->
        conn |> put_status(409) |> json(%{error: "version"})

      {:error, :elsewhere} ->
        conn |> put_status(403) |> json(%{error: "elsewhere"})

      {:error, :bad_request} ->
        conn |> put_status(400) |> json(%{error: "bad_request"})

      {:error, _used_or_expired} ->
        conn |> put_status(410) |> json(%{error: "used_or_expired"})
    end
  end

  def show(conn, %{"code" => code}), do: render(conn, :show, code: code)
end
