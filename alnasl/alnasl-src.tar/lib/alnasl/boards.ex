defmodule Alnasl.Boards do
  @moduledoc """
  The boards the box knows, and everything the site does with one.

  A board is a row (`Alnasl.Boards.Board`) and, while it is connected, a
  process (`Alnasl.BoardServer`). This module is the one door to both:
  adding and removing boards, connecting and disconnecting them, linking
  them to the games of the round, and the arbiter's repair tools.

  The round model in short:

  - a board plays in a tournament (`tournament_id`; the box's own unless
    its table was given to another), and round and board numbers are that
    tournament's;
  - the arbiter **links** a physical board to "board N of round R". The game
    is `(R, N)`, whichever physical board feeds it;
  - a board linked to a game another board already has takes it over - a
    board carried to another table mid-round, or a broken board swapped for a
    spare. The game continues from the moves it has;
  - a board linked late is caught up by the tracker if it can be (a few
    moves in), and by the arbiter if not (the repair tools);
  - a game that does not start from the standard position gets a FEN before
    the first move (`set_fen/2`).
  """

  import Ecto.Query, only: [order_by: 3]

  alias Alnasl.{BoardServer, Games, Log, Outbox, Pgn, Repo, Tables, Tournaments}
  alias Arkab.Transport
  alias Alnasl.Boards.Board

  def subscribe, do: BoardServer.subscribe()

  # --- rows --------------------------------------------------------------------

  def list, do: Board |> order_by([b], [b.board_no, b.id]) |> Repo.all()
  def get(id), do: Repo.get(Board, id)
  def get!(id), do: Repo.get!(Board, id)

  def create(attrs) do
    attrs = Map.new(attrs)
    hall_id = attrs[:hall_id] || attrs["hall_id"] || Alnasl.Halls.own_id()

    attrs =
      attrs |> Map.drop([:hall_id, "hall_id"]) |> encode_options() |> in_a_tournament(hall_id)

    with {:ok, board} <- %Board{hall_id: hall_id} |> Board.changeset(attrs) |> Repo.insert() do
      Log.add(:info, "board.added", %{name: board.name, driver: board.driver}, %{
        board_id: board.id
      })

      if board.enabled, do: start(board)
      notify(board.id)
      Tournaments.notify(board.tournament_id)
      {:ok, board}
    end
  end

  def update(%Board{} = board, attrs) do
    attrs = attrs |> Map.new() |> encode_options()

    with {:ok, updated} <- board |> Board.changeset(attrs) |> Repo.update() do
      rewired? =
        {updated.driver, updated.port, updated.address, updated.options} !=
          {board.driver, board.port, board.address, board.options}

      cond do
        not updated.enabled -> stop(updated)
        rewired? or not running?(updated.id) -> restart(updated)
        true -> call(updated.id, {:reload, updated})
      end

      notify(updated.id)
      {:ok, updated}
    end
  end

  def delete(%Board{} = board) do
    stop(board)
    Repo.delete(board)
    Alnasl.Recorder.remember_hall(board.id, board.hall_id)
    Log.add(:info, "board.removed", %{name: board.name}, %{board_id: board.id})
    notify(board.id)
    Tournaments.notify(board.tournament_id)
    :ok
  end

  # A board belongs to a tournament from the start: the one whoever adds it
  # names; else the only linked tournament there is, while the box's own has
  # never been used (`Alnasl.Seating.default_tournament/0`); else the box's
  # own. A board in another hall than the box's own (a bridge's) plays in
  # that hall's tournament: a hall's boards do not wander into another's.
  defp in_a_tournament(attrs, hall_id) do
    cond do
      attrs[:tournament_id] || attrs["tournament_id"] ->
        attrs

      hall_id == Alnasl.Halls.own_id() ->
        tournament = Alnasl.Seating.default_tournament() || Tournaments.default()
        Map.put(attrs, :tournament_id, tournament.id)

      true ->
        Map.put(attrs, :tournament_id, Alnasl.Halls.local_tournament(hall_id).id)
    end
  end

  defp encode_options(attrs) do
    case attrs[:options] || attrs["options"] do
      %{} = options -> attrs |> Map.delete("options") |> Map.put(:options, Jason.encode!(options))
      _other -> attrs
    end
  end

  # --- processes ---------------------------------------------------------------

  def running?(id), do: BoardServer.whereis(id) != nil

  @doc """
  Whether this box reads boards of its own: serial ports, loops,
  simulators, replays. Not on a box set up with `ALNASL_NO_LOCAL_BOARDS`
  (the hosted server), which has no hall attached and nothing to plug in;
  its boards arrive from bridges (`Alnasl.Driver.Remote`) and nothing else
  is started, whatever an old row says.
  """
  def local?, do: Alnasl.edition() == :box

  @doc "Connects a board: starts its process and its driver."
  def start(%Board{driver: driver} = board) when driver != "remote" do
    if local?(), do: start_server(board), else: {:error, :no_local_boards}
  end

  def start(%Board{} = board), do: start_server(board)

  defp start_server(%Board{} = board) do
    case DynamicSupervisor.start_child(Alnasl.BoardSupervisor, {BoardServer, board}) do
      {:ok, pid} -> {:ok, pid}
      {:error, {:already_started, pid}} -> {:ok, pid}
      error -> error
    end
  end

  @doc "Disconnects a board. Its game stays as it is."
  def stop(%Board{id: id}) do
    case BoardServer.whereis(id) do
      nil ->
        :ok

      pid ->
        DynamicSupervisor.terminate_child(Alnasl.BoardSupervisor, pid)
        notify(id)
        :ok
    end
  end

  def restart(%Board{} = board) do
    stop(board)
    start(get!(board.id))
  end

  @doc "Starts every enabled board. Called when the application starts."
  def start_all do
    switch_over()
    for board <- list(), board.enabled, do: start(board)
    :ok
  end

  def connect(%Board{} = board), do: update(board, %{enabled: true})
  def disconnect(%Board{} = board), do: update(board, %{enabled: false})

  defp call(id, message, default \\ {:error, :not_running}) do
    case BoardServer.whereis(id) do
      nil -> default
      pid -> GenServer.call(pid, message, 15_000)
    end
  catch
    :exit, _reason -> default
  end

  defp notify(id), do: Phoenix.PubSub.broadcast(Alnasl.PubSub, "boards", {:board, id})

  # --- what the site shows -----------------------------------------------------

  @doc "The board as the site shows it. A board that is not connected has a short snapshot."
  def snapshot(%Board{} = board) do
    case call(board.id, :snapshot, nil) do
      nil -> offline(board)
      snapshot -> snapshot
    end
    # The hall from the row, not the server's copy: a bridge moved to another
    # hall is there at once.
    |> Map.put(:hall_id, board.hall_id)
  end

  def snapshot(id) when is_integer(id) do
    case get(id) do
      nil -> nil
      board -> snapshot(board)
    end
  end

  def snapshots, do: Enum.map(list(), &snapshot/1)

  defp offline(board) do
    game =
      board.round && board.board_no &&
        Games.current(board.tournament_id, board.round, board.board_no)

    %{
      id: board.id,
      name: board.name,
      driver: board.driver,
      port: board.port,
      address: board.address,
      tournament_id: board.tournament_id,
      round: board.round,
      board_no: board.board_no,
      table_no: board.table_no,
      flipped: board.flipped,
      serial: board.serial,
      firmware: board.firmware,
      running?: false,
      connected?: false,
      last_seen: nil,
      stats: %{positions: 0, polls_ok: 0, polls_missed: 0},
      info: %{},
      raw: nil,
      warning: nil,
      player: nil,
      linked?: game != nil,
      status: if(game && game.status == "finished", do: :finished, else: :no_signal),
      detail: nil,
      plies:
        if(game, do: Enum.map(Games.plies(game), &Map.take(&1, [:san, :flags, :read])), else: []),
      unseen: [],
      clock: nil,
      clock_check: nil,
      clock_alarm: nil,
      problems: [],
      white: game && game.white,
      black: game && game.black,
      result: game && game.result,
      suggestion: game && game.suggestion,
      paused: game && game.paused,
      game_status: game && game.status,
      game_id: game && game.id,
      game_no: game && game.game_no,
      local: game && game.local,
      pairing_flag: game && game.pairing_flag,
      fen: game && elem(Games.position(game), 0),
      certain: nil,
      last_move: game && elem(Games.position(game), 1)
    }
  end

  @doc """
  What could be connected: every serial port the machine offers (with a note
  when a board already uses it), and whether the serial library is there at
  all.
  """
  def discover do
    used = Map.new(list(), &{&1.port, &1.name})
    # A box without boards of its own does not go looking for ports either.
    ports = if local?(), do: Transport.ports(), else: []

    %{
      serial?: local?() and Transport.Uart.available?(),
      ports: Enum.map(ports, &Map.put(&1, :used_by, used[&1.port])),
      games: length(Pgn.all_bundled())
    }
  end

  # --- linking -----------------------------------------------------------------

  @doc """
  Links a board to board `board_no` of `round` of its tournament. A board
  that had that game lets go of it.
  """
  def link(%Board{} = board, round, board_no) when is_integer(round) and is_integer(board_no) do
    for other <- list(),
        other.id != board.id,
        other.tournament_id == board.tournament_id,
        other.round == round,
        other.board_no == board_no do
      Log.add(:info, "board.moved", %{from: other.name, to: board.name}, %{
        round: round,
        board_no: board_no
      })

      update(other, %{round: nil, board_no: nil})
    end

    Log.add(:info, "board.linked", %{name: board.name}, %{
      board_id: board.id,
      round: round,
      board_no: board_no
    })

    update(board, %{round: round, board_no: board_no})
  end

  def unlink(%Board{} = board) do
    Log.add(:info, "board.unlinked", %{name: board.name}, %{
      board_id: board.id,
      round: board.round,
      board_no: board.board_no
    })

    update(board, %{round: nil, board_no: nil})
  end

  @doc """
  Links the boards, in the order they are listed, to boards `first`,
  `first + 1`, ... of `round`: twelve boards set out in a row are one click.
  """
  def link_in_order(round, first \\ 1) do
    list()
    |> Enum.sort_by(& &1.id)
    |> Enum.with_index(first)
    |> Enum.each(fn {board, number} -> link(board, round, number) end)
  end

  @doc """
  Moves every linked board of a tournament on to another round: the next
  round begins. A board with a table number feeds the board its table
  stands for again; one without keeps the board number it had. The boards
  of the other tournaments are not touched.
  """
  def move_to_round(tournament_id, round) do
    # A board with a sticker goes back to its own number: "table 7 plays
    # board 3" was said for a round, not for the tournament.
    for board <- list(), board.tournament_id == tournament_id do
      case Tables.home_board(board, round) || board.board_no do
        nil -> :ok
        number -> link(board, round, number)
      end
    end

    Tournaments.set_round(tournament_id, round)
    :ok
  end

  @doc "`move_to_round/2` for the box's own tournament."
  def move_to_round(round), do: move_to_round(Tournaments.default_id(), round)

  def flip(%Board{id: id}, flipped?), do: call(id, {:flip, flipped?})
  def pause_player(%Board{id: id}), do: call(id, {:driver, :pause})
  def resume_player(%Board{id: id}), do: call(id, {:driver, :resume})
  def note(%Board{id: id}, text), do: call(id, {:note, text})

  # --- the repair tools --------------------------------------------------------

  def undo(id), do: call(id, {:repair, :undo, nil})
  def append(id, sans), do: call(id, {:repair, :append, sans})
  def edit(id, number, san), do: call(id, {:repair, :edit, {number, san}})
  def set_fen(id, fen), do: call(id, {:repair, :set_fen, fen})
  def resync(id, depth \\ 6), do: call(id, {:repair, :resync, depth})

  @doc "The other ways the reconstructed moves around ply `number` can have gone (`Alnasl.Tracker.alternatives/2`)."
  def alternatives(id, number) do
    case call(id, {:repair, :alternatives, number}) do
      {:ok, found} -> found
      {:error, :not_running} = down -> down
      _error -> nil
    end
  end

  @doc "The arbiter picks one of them: the game is rewritten from there and sent again."
  def choose(id, number, sans), do: call(id, {:repair, :choose, {number, sans}})
  def pause(id, paused?), do: call(id, {:repair, :pause, paused?})
  def reopen(id), do: call(id, {:repair, :reopen, nil})

  @doc """
  A new game on that board, in the same round: the game there is closed
  (without a result, if it had none) and kept, and the board begins again.
  """
  def new_game(id, kind \\ :auto) when kind in [:auto, :extra, :replace],
    do: call(id, {:repair, :new_game, kind})

  @doc """
  The game on the board leaves the box from now on, and the one that was
  leaving stays here. Without a running board, the game is switched directly.
  """
  def send_this(%Games.Game{} = game) do
    case linked_running(game.tournament_id, game.round, game.board_no) do
      nil ->
        switched = Games.make_sendable(game)

        Log.add(:info, "game.switched", %{game: switched.game_no}, %{
          round: game.round,
          board_no: game.board_no
        })

        Outbox.enqueue(switched, nil, true)
        :ok

      board ->
        call(board.id, {:repair, :send_this, nil})
    end
  end

  @doc "Run at start-up: see `Alnasl.Games.switch_over/0`."
  def switch_over, do: Games.switch_over()

  @doc """
  Starts round `round` of a tournament: every board of that tournament
  moves to that round (`move_to_round/2`) and takes the names the pairings
  give its board. What "Start round N" on the Round page does, and what
  happens by itself when the pairing program pairs a round
  (`Alnasl.OpenPairings.Sync`).
  """
  def start_round(tournament_id, round) when is_integer(round) and round >= 1 do
    move_to_round(tournament_id, round)

    Log.add(:info, "round.started", %{
      round: round,
      tournament: tournament_name(tournament_id)
    })

    :ok
  end

  @doc "`start_round/2` for the box's own tournament."
  def start_round(round) when is_integer(round), do: start_round(Tournaments.default_id(), round)

  defp tournament_name(id) do
    case Tournaments.get(id) do
      nil -> ""
      tournament -> Tournaments.title(tournament) || ""
    end
  end

  @doc """
  The games of a tournament changed behind the boards' backs - names, a
  pairing flag: every board of it reads its game again.
  """
  def refresh_games(tournament_id) do
    for board <- list(), board.tournament_id == tournament_id do
      call(board.id, :reload_game, :ok)
      notify(board.id)
    end

    :ok
  end

  # --- a pairing that changed under a game -------------------------------------

  @doc """
  The game is the new pairing's: the moves stand, the names and the pairing
  become what the pairing program now says for that board, and every
  destination is told again, in full.
  """
  def adopt_pairing(%Games.Game{} = game) do
    pairing = Tournaments.board(game.tournament_id, game.round, game.board_no)
    game = game |> Games.adopt(pairing) |> Outbox.enqueue(nil, true)
    Log.add(:info, "pairing.adopted", %{}, %{round: game.round, board_no: game.board_no})
    refresh_games(game.tournament_id)
    {:ok, game}
  end

  @doc """
  The game is set aside (kept on the box, with its PGN) and a new one
  begins on that board for the pairing as it is now.
  """
  def set_aside(%Games.Game{} = game) do
    case linked_running(game.tournament_id, game.round, game.board_no) do
      nil ->
        pairing = Tournaments.board(game.tournament_id, game.round, game.board_no)
        {_aside, fresh} = Games.set_aside(game, pairing)
        Log.add(:info, "pairing.set_aside", %{}, %{round: game.round, board_no: game.board_no})
        {:ok, Outbox.enqueue(fresh, nil, true)}

      board ->
        call(board.id, {:repair, :set_aside, nil})
    end
  end

  @doc "Sets the result of the game on a board. The arbiter's word."
  def set_result(id, result), do: call(id, {:repair, :result, result})

  # --- games without a board ---------------------------------------------------

  @doc """
  Sets the result of a game no connected board is feeding (one attached from
  a PGN, or whose board is switched off).
  """
  def set_game_result(round, board_no, result),
    do: set_game_result(Tournaments.default_id(), round, board_no, result)

  def set_game_result(tournament_id, round, board_no, result) do
    case linked_running(tournament_id, round, board_no) do
      nil ->
        with %{} = game <- Games.current(tournament_id, round, board_no) do
          Log.add(:info, "result.set", %{result: result, by: "arbiter"}, %{
            round: round,
            board_no: board_no
          })

          game |> Games.finish(result) |> Outbox.enqueue(nil, false)
          :ok
        end

      board ->
        set_result(board.id, result)
    end
  end

  @doc """
  Attaches a game from a PGN to board `board_no` of `round` - a game that was
  played but not captured. It replaces what the box and the server hold for
  that board. A connected board linked to it lets go.
  """
  def attach_pgn(round, board_no, %{moves: _} = pgn_game),
    do: attach_pgn(Tournaments.default_id(), round, board_no, pgn_game)

  def attach_pgn(tournament_id, round, board_no, %{moves: moves} = pgn_game) do
    if board = linked_running(tournament_id, round, board_no), do: unlink(board)

    for board <- list(),
        board.tournament_id == tournament_id,
        board.round == round,
        board.board_no == board_no do
      update(board, %{round: nil, board_no: nil})
    end

    pairing = Tournaments.board(tournament_id, round, board_no)
    names = pairing || %{}

    game =
      Games.ensure(
        tournament_id,
        round,
        board_no,
        Map.merge(Games.pairing_attrs(pairing), %{
          white: names[:white] || pgn_game.headers["White"],
          black: names[:black] || pgn_game.headers["Black"]
        })
      )

    result = if pgn_game.result in ["1-0", "0-1", "1/2-1/2"], do: pgn_game.result, else: "*"
    game = game |> Games.pause(false) |> Games.attach(moves, result, pgn_game[:start_fen])

    Log.add(:info, "pgn.attached", %{moves: length(moves), result: result, by: "arbiter"}, %{
      round: round,
      board_no: board_no
    })

    {:ok, Outbox.enqueue(game, nil, true)}
  end

  defp linked_running(tournament_id, round, board_no) do
    Enum.find(
      list(),
      &(&1.tournament_id == tournament_id and &1.round == round and &1.board_no == board_no and
          running?(&1.id))
    )
  end

  # --- demonstrations ----------------------------------------------------------

  @doc """
  Adds `count` simulator boards playing bundled games (or `games`, a list of
  `Alnasl.Pgn` games), linked to boards 1..count of `round`. Returns them.
  """
  def add_simulators(count, round, opts \\ []) do
    games = Keyword.get(opts, :games)
    faults = Keyword.get(opts, :faults, %{})
    profile = Keyword.get(opts, :profile)
    speed = Keyword.get(opts, :speed, 20)
    first = Keyword.get(opts, :first, 1)
    tournament_id = Keyword.get(opts, :tournament_id) || Tournaments.default_id()
    existing = length(list())

    for i <- 1..count do
      options =
        %{
          "speed" => speed,
          "faults" => faults,
          "profile" => profile,
          "seed" => existing + i,
          "start_delay_ms" => 3_000 * i
        }
        |> Map.merge(
          case games && Enum.at(games, i - 1) do
            %{moves: moves} = game -> %{"moves" => moves, "start_fen" => game[:start_fen]}
            nil -> %{"game" => existing + i}
          end
        )

      {:ok, board} =
        create(%{
          name: "Sim #{existing + i}",
          driver: "simulator",
          port: "sim-#{existing + i}",
          options: options,
          tournament_id: tournament_id,
          round: round,
          board_no: first + i - 1
        })

      board
    end
  end
end
