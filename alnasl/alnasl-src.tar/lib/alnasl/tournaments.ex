defmodule Alnasl.Tournaments do
  @moduledoc """
  The tournaments the box serves, and what it knows of each: who plays whom
  on which board, which round is on, where its games go.

  ## More than one

  A hall has one box and often several tournaments: tables 1-4 the Open,
  5-8 the under-twelves. Each is a row (`Alnasl.Tournaments.Tournament`)
  with its own pairings, its own round in play, its own results page and
  Lichess round. Which table plays in which tournament is said here, on the
  box (`assign_tables/4`, `Alnasl.Tables`); board numbers begin again at 1
  in each, so table 5 can be board 1. And one tournament can be played in
  more than one hall: boards 1-8 here, 9-16 next door
  (`Alnasl.Placements`).

  ## The box's own

  One tournament is always there: the box's own (`default/0`, kind
  `"local"`). It is what a box with no pairing program has - names typed
  in or read from a PGN, a results page typed in on Setup - and where a
  board belongs that nobody has given to another tournament.

  ## Where the pairings come from

  For a linked tournament, from its pairing program
  (`Alnasl.OpenPairings`), which is asked every few seconds; the answer is
  kept (`document`), so the box knows the pairings with the network gone.
  For the box's own, from nowhere but the arbiter: `set_names/5`, or a PGN
  attached to a board. The box does not read pairings from the results
  server any more: that link is one way, moves out.
  """

  import Ecto.Query, only: [from: 2, order_by: 3, select: 3, distinct: 2, where: 3]

  alias Alnasl.{Placements, Repo}
  alias Alnasl.Tournaments.{Link, Tournament}

  @topic "tournaments"

  def subscribe, do: Phoenix.PubSub.subscribe(Alnasl.PubSub, @topic)

  @doc "Tells every page that tournament `id` changed (`{:tournament, id}`)."
  def notify(id), do: Phoenix.PubSub.broadcast(Alnasl.PubSub, @topic, {:tournament, id})

  # --- rows --------------------------------------------------------------------

  @doc "The box's own tournament. Made if it is not there."
  def default do
    own = Alnasl.Halls.own_id()

    case Repo.one(
           from t in Tournament,
             where: t.kind == "local" and (is_nil(t.hall_id) or t.hall_id == ^own),
             order_by: t.id,
             limit: 1
         ) do
      nil -> Repo.insert!(%Tournament{kind: "local", hall_id: own})
      tournament -> tournament
    end
  end

  def default_id, do: default().id

  @doc "Every tournament: the box's own first, then in the order they were added."
  def list do
    Tournament
    |> order_by([t], asc: fragment("CASE WHEN ? = 'local' THEN 0 ELSE 1 END", t.kind), asc: t.id)
    |> Repo.all()
  end

  def get(nil), do: nil
  def get(id), do: Repo.get(Tournament, id)
  def get!(id), do: Repo.get!(Tournament, id)

  @doc """
  The tournaments to show: every linked one the pairing program still
  names, and the box's own when it has a board - or when it is all there is.
  """
  def active do
    with_boards =
      Alnasl.Boards.Board |> select([b], b.tournament_id) |> distinct(true) |> Repo.all()

    all = list()
    linked = Enum.filter(all, &(&1.kind == "linked" and not &1.gone))

    own =
      Enum.filter(
        all,
        &((&1.kind == "local" and (linked == [] or &1.id in with_boards)) or
            (&1.gone and &1.id in with_boards))
      )

    Enum.sort_by(own ++ linked, &{&1.kind != "local", &1.id})
  end

  @doc "Is there more than one tournament to tell apart?"
  def many?, do: length(active()) > 1

  @doc "What to call it on a tile: its short label, else its name."
  def title(%Tournament{label: label}) when is_binary(label) and label != "", do: label
  def title(%Tournament{name: name}) when is_binary(name) and name != "", do: name
  def title(%Tournament{}), do: nil

  def linked?(%Tournament{kind: kind}), do: kind == "linked"

  def update(%Tournament{} = tournament, attrs) do
    with {:ok, updated} <- tournament |> Tournament.changeset(Map.new(attrs)) |> Repo.update() do
      notify(updated.id)
      Alnasl.Destination.settings_changed()
      {:ok, updated}
    end
  end

  def update!(%Tournament{} = tournament, attrs) do
    {:ok, updated} = update(tournament, attrs)
    updated
  end

  @doc """
  Takes a tournament off the box: its boards go back to the box's own
  tournament, not linked to a game, and its games are forgotten here (the
  PGN files already written stay on the disk). The box's own cannot go.
  """
  def remove(%Tournament{kind: "local"}), do: {:error, :own}

  def remove(%Tournament{} = tournament) do
    own = default()

    for board <- Alnasl.Boards.list(), board.tournament_id == tournament.id do
      Alnasl.Boards.update(board, %{tournament_id: own.id, round: nil, board_no: nil})
    end

    Repo.delete_all(from g in Alnasl.Games.Game, where: g.tournament_id == ^tournament.id)
    Placements.delete_all(tournament.id)
    Repo.delete!(tournament)
    notify(tournament.id)
    :ok
  end

  # --- the round ---------------------------------------------------------------

  @doc "The round the box has on that tournament's boards."
  def round_in_play(id) do
    case get(id) do
      %Tournament{round: round} when is_integer(round) -> round
      _none -> 1
    end
  end

  def set_round(id, round) when is_integer(round) and round > 0 do
    case get(id) do
      %Tournament{round: ^round} = same -> same
      %Tournament{} = tournament -> update!(tournament, %{round: round})
      nil -> nil
    end
  end

  # --- the results page and the Lichess round ----------------------------------

  def openresults_configured?(%Tournament{server_url: url, slug: slug, relay_key: key}),
    do: url not in [nil, ""] and slug not in [nil, ""] and key not in [nil, ""]

  def lichess_configured?(%Tournament{lichess_round_id: id, lichess_token: token}),
    do: id not in [nil, ""] and token not in [nil, ""]

  @doc "The round of the tournament that goes to its Lichess round."
  def lichess_round(%Tournament{lichess_round: n}) when is_integer(n) and n > 0, do: n
  def lichess_round(%Tournament{round: round}), do: round || 1

  @doc "`\"orrk_...9f2c\"`: enough to tell two secrets apart, not enough to use one."
  def hint(secret, lead \\ 5)

  def hint(secret, lead) when is_binary(secret) and byte_size(secret) > 12,
    do: String.slice(secret, 0, lead) <> "..." <> String.slice(secret, -4, 4)

  def hint(secret, _lead) when is_binary(secret) and secret != "", do: "..."
  def hint(_none, _lead), do: nil

  def relay_key_hint(%Tournament{relay_key: key}), do: hint(key)
  def lichess_token_hint(%Tournament{lichess_token: token}), do: hint(token, 4)
  def secret_hint(%Link{secret: secret}), do: hint(secret)

  # --- tables ------------------------------------------------------------------

  @doc """
  The range of tables the tournament has in hall `hall_id` (its own hall
  when none is named): `{from, to}`, `{nil, nil}` for every free table,
  `nil` when it is not played there. See `Alnasl.Placements`.
  """
  def tables(%Tournament{} = tournament, hall_id \\ nil) do
    case Placements.in_hall(tournament, hall_id || Alnasl.Halls.of(tournament)) do
      nil -> nil
      placement -> {placement.table_from, placement.table_to}
    end
  end

  @doc """
  Tables `from` to `to` of hall `hall_id` (the tournament's own hall when
  none is named) play in this tournament, table `from` being the first
  board it has there (board 1, unless it is played in another hall as
  well). Every board of that hall that carries one of those numbers moves
  over, to the board its table now stands for; a range another tournament
  had there that overlaps is given up. `nil, nil` forgets the range: every
  table no other range holds.
  """
  def assign_tables(tournament, from, to, hall_id \\ nil)

  def assign_tables(%Tournament{} = tournament, nil, nil, hall_id) do
    hall_id = hall_id || Alnasl.Halls.of(tournament)

    with {:ok, _placement, _carried} <-
           Placements.put(tournament, hall_id, %{table_from: nil, table_to: nil}) do
      {:ok, get!(tournament.id)}
    end
  end

  def assign_tables(%Tournament{} = tournament, from, to, hall_id)
      when is_integer(from) and is_integer(to) and from > 0 and to >= from do
    with {:ok, tournament, _carried} <- assign_tables_carry(tournament, from, to, hall_id),
         do: {:ok, tournament}
  end

  def assign_tables(_tournament, _from, _to, _hall_id), do: {:error, :range}

  @doc """
  `assign_tables/4`, and what became of a game under way on a board that
  moved with its table: `{:ok, tournament, [carried]}`, each
  `Alnasl.Tables.assign_carry/3`'s account of it. `{:error, :boards}` when
  the range would hold boards the tournament plays in another hall.
  """
  def assign_tables_carry(tournament, from, to, hall_id \\ nil)

  def assign_tables_carry(%Tournament{} = tournament, from, to, hall_id)
      when is_integer(from) and is_integer(to) and from > 0 and to >= from do
    hall_id = hall_id || Alnasl.Halls.of(tournament)

    with {:ok, _placement, carried} <-
           Placements.put(tournament, hall_id, %{table_from: from, table_to: to}, give_up: true) do
      tournament = get!(tournament.id)

      Alnasl.Log.add(:info, "tournament.tables", %{
        tournament: title(tournament) || "",
        from: from,
        to: to
      })

      {:ok, tournament, carried}
    end
  end

  def assign_tables_carry(_tournament, _from, _to, _hall_id), do: {:error, :range}

  @doc "The tournament whose range of tables in hall `hall_id` holds table `number`, if any."
  def for_table(number, hall_id \\ nil), do: Placements.for_table(number, hall_id)

  @doc """
  The board of the round that table `number` of hall `hall_id` stands for
  in this tournament: the tables are counted from the first one its
  placement there has, that table being the placement's first board
  (`Alnasl.Placements.board_at/3`). `hall_id` is the tournament's own hall
  when none is named.

  In a team event that keeps each match together (`keep_matches`, on by
  default) the count is in matches and then boards: with four boards a
  match, the fifth table is board 1 of match 2, whatever number the
  pairing program gave that board in the round. A place no pairing names
  (a team with the bye, a line-up not entered yet) stands for the number
  it would have in a round numbered match by match. `round` is the round
  the table is wanted for (the one on the boards by default).
  """
  def board_of_table(tournament, number, round \\ nil, hall_id \\ nil)

  def board_of_table(tournament, number, round, hall_id),
    do: board_of_table_in(tournament, number, round, hall_id, nil)

  @doc """
  `board_of_table/4` with the tournament's placements already in hand
  (`Alnasl.Placements.list/1`), for a caller asking about many tables.
  """
  def board_of_table_in(%Tournament{} = tournament, number, round, hall_id, placements)
      when is_integer(number) do
    hall_id = hall_id || Alnasl.Halls.of(tournament)

    case Placements.board_at(tournament, hall_id, number, placements) do
      nil -> nil
      k -> by_match(tournament, k, round)
    end
  end

  def board_of_table_in(_tournament, _number, _round, _hall_id, _placements), do: nil

  defp by_match(%Tournament{keep_matches: true, kind: "linked"} = tournament, k, round) do
    with true <- team_event?(tournament),
         per when is_integer(per) <- boards_per_match(tournament) do
      {number, place} = {div(k - 1, per) + 1, rem(k - 1, per) + 1}

      found =
        Enum.find(boards(tournament.id, round || tournament.round), fn b ->
          b.match != nil and b.match.number == number and b.match.board == place
        end)

      if found, do: found.board, else: k
    else
      _plain -> k
    end
  end

  defp by_match(_tournament, k, _round), do: k

  # --- the pairings ------------------------------------------------------------

  @doc "What the box holds of a tournament's pairings, decoded; `nil` when nothing."
  def document(%Tournament{document: nil}), do: nil

  def document(%Tournament{document: json}) do
    case Jason.decode(json) do
      {:ok, %{} = document} -> document
      _broken -> nil
    end
  end

  def document(id) when is_integer(id), do: id |> get() |> then(&(&1 && document(&1)))
  def document(nil), do: nil

  @doc "Name, site and rate of play, for PGN headers and the page title."
  def info(id) do
    tournament = get(id)
    document = tournament && document(tournament)
    described = (document && document["tournament"]) || %{}

    %{
      name: described["name"] || (tournament && tournament.name),
      city: described["site"] || described["city"],
      planned_rounds: described["rounds"],
      time_control: get_in(described, ["time_control", "text"]),
      time_control_pgn: get_in(described, ["time_control", "pgn"]),
      display: described["display"] || %{}
    }
  end

  @doc "The numbers of the rounds that are paired."
  def rounds(id) do
    case document(id) do
      %{"rounds" => rounds} when is_list(rounds) ->
        rounds |> Enum.map(& &1["number"]) |> Enum.filter(&is_integer/1) |> Enum.sort()

      _none ->
        []
    end
  end

  @doc """
  The boards of a round that have a game to follow, in board order:
  `[%{board, label, game, kind, white, black, white_id, black_id,
  white_rating, black_rating, result, match, white_team, black_team}]` with
  `white` and `black` the names as a tile shows them (title first).
  A bye has no board to set up and is left out.

  In a team event `match` is `%{number, board, team_a, team_b}` - the
  match's number in the round, the board's place in the match, and the two
  teams as the pairing program names them - and `white_team` and
  `black_team` say which team each player plays for. Elsewhere all three
  are `nil`.
  """
  def boards(id, round) do
    with %{"rounds" => rounds} = document <- document(id),
         %{"boards" => boards} <- Enum.find(rounds, &(&1["number"] == round)) do
      players = players_by_id(document)

      boards
      |> Enum.filter(&(is_integer(&1["board"]) and &1["kind"] != "bye"))
      |> Enum.map(fn b ->
        %{
          board: b["board"],
          label: b["label"],
          game: b["game"],
          kind: b["kind"] || "game",
          white: tile_name(players[b["white"]]),
          black: tile_name(players[b["black"]]),
          white_id: b["white"],
          black_id: b["black"],
          white_rating: rating(players[b["white"]]),
          black_rating: rating(players[b["black"]]),
          result: b["result"],
          match: match(b["match"]),
          white_team: team(players[b["white"]]),
          black_team: team(players[b["black"]])
        }
      end)
      |> Enum.sort_by(& &1.board)
    else
      _none -> []
    end
  end

  defp match(%{"number" => number, "board" => board} = match)
       when is_integer(number) and is_integer(board) do
    %{
      number: number,
      board: board,
      team_a: text_or_nil(match["team_a"]),
      team_b: text_or_nil(match["team_b"])
    }
  end

  defp match(_none), do: nil

  defp team(%{"team" => team}), do: text_or_nil(team)
  defp team(_none), do: nil

  defp text_or_nil(value) when is_binary(value) and value != "", do: value
  defp text_or_nil(_none), do: nil

  # --- team events -------------------------------------------------------------

  @doc """
  Is it a team event? The pairing program says so in the document
  (`tournament.team_event`); the box's own tournament never is.
  """
  def team_event?(%Tournament{kind: "local"}), do: false

  def team_event?(%Tournament{} = tournament),
    do: get_in(document(tournament) || %{}, ["tournament", "team_event"]) == true

  def team_event?(id) when is_integer(id), do: id |> get() |> then(&(&1 && team_event?(&1)))
  def team_event?(nil), do: false

  @doc "How many boards a match has in a team event, else `nil`."
  def boards_per_match(%Tournament{} = tournament) do
    case get_in(document(tournament) || %{}, ["tournament", "boards_per_match"]) do
      n when is_integer(n) and n > 0 -> n
      _none -> nil
    end
  end

  def boards_per_match(id) when is_integer(id),
    do: id |> get() |> then(&(&1 && boards_per_match(&1)))

  @doc """
  The teams of the two players of a game, by the player ids the box
  believes are playing it: `{white team | nil, black team | nil}`. Both
  `nil` outside a team event.
  """
  def game_teams(tournament_id, white_id, black_id) do
    with true <- team_event?(tournament_id),
         %{} = document <- document(tournament_id) do
      players = players_by_id(document)
      {team(players[white_id]), team(players[black_id])}
    else
      _none -> {nil, nil}
    end
  end

  def board(id, round, board_no), do: Enum.find(boards(id, round), &(&1.board == board_no))

  @doc "Where the pairing program's game `game` is now: `{round, board}` or `nil`."
  def find_game(_id, nil), do: nil

  def find_game(id, game) do
    case document(id) do
      %{"rounds" => rounds} when is_list(rounds) ->
        Enum.find_value(rounds, fn round ->
          Enum.find_value(List.wrap(round["boards"]), fn b ->
            if b["game"] == game and b["kind"] != "bye", do: {round["number"], b["board"]}
          end)
        end)

      _none ->
        nil
    end
  end

  @doc """
  The two players of a board as the pairing program describes them:
  `%{white: player | nil, black: player | nil}`, each a map with `:name`,
  `:title`, `:rating`, `:fide_id` and `:federation` (any of them `nil`).
  For destinations that want more than a name.
  """
  def players(id, round, board_no) do
    with %{"rounds" => rounds} = document <- document(id),
         %{"boards" => boards} <- Enum.find(rounds, &(&1["number"] == round)),
         %{} = board <- Enum.find(boards, &(&1["board"] == board_no)) do
      by_id = players_by_id(document)
      %{white: player(by_id[board["white"]]), black: player(by_id[board["black"]])}
    else
      _none -> %{white: nil, black: nil}
    end
  end

  defp rating(%{"rating" => rating}) when is_integer(rating) and rating > 0, do: rating
  defp rating(_none), do: nil

  defp players_by_id(document),
    do: Map.new(List.wrap(document["players"]), &{&1["id"], &1})

  defp player(%{"name" => name} = p) when is_binary(name) do
    %{
      name: name,
      title: if(p["title"] in [nil, ""], do: nil, else: p["title"]),
      rating: if(is_integer(p["rating"]) and p["rating"] > 0, do: p["rating"]),
      fide_id: if(is_integer(p["fide_id"]) and p["fide_id"] > 0, do: p["fide_id"]),
      federation: if(p["federation"] in [nil, ""], do: nil, else: p["federation"]),
      team: team(p)
    }
  end

  defp player(_none), do: nil

  defp tile_name(%{"name" => name} = player) when is_binary(name) do
    case player["title"] do
      title when is_binary(title) and title != "" -> "#{title} #{name}"
      _none -> name
    end
  end

  defp tile_name(_other), do: nil

  @doc """
  Says by hand who plays a board of the box's own tournament - the box has
  no pairing program to ask. Kept with the pairings, so the next board
  linked to that number, the PGN and the Lichess round all know. An empty
  name takes the player away.
  """
  def set_names(%Tournament{kind: "local"} = tournament, round, board_no, white, black)
      when is_integer(round) and is_integer(board_no) do
    document = document(tournament) || %{"tournament" => %{}, "players" => [], "rounds" => []}
    {white_id, document} = player_named(document, white)
    {black_id, document} = player_named(document, black)

    entry = %{
      "game" => nil,
      "board" => board_no,
      "label" => to_string(board_no),
      "kind" => "game",
      "white" => white_id,
      "black" => black_id,
      "result" => nil
    }

    rounds = List.wrap(document["rounds"])

    this =
      Enum.find(rounds, &(&1["number"] == round)) || %{"number" => round, "boards" => []}

    boards =
      this["boards"]
      |> List.wrap()
      |> Enum.reject(&(&1["board"] == board_no))
      |> then(&if(white_id || black_id, do: [entry | &1], else: &1))
      |> Enum.sort_by(& &1["board"])

    rounds =
      [Map.put(this, "boards", boards) | Enum.reject(rounds, &(&1["number"] == round))]
      |> Enum.reject(&(&1["boards"] == []))
      |> Enum.sort_by(& &1["number"])

    update(tournament, %{
      document: Jason.encode!(Map.put(document, "rounds", rounds)),
      document_at: DateTime.utc_now(:second)
    })
  end

  def set_names(%Tournament{}, _round, _board_no, _white, _black), do: {:error, :linked}

  defp player_named(document, name) do
    name = String.trim(name || "")
    players = List.wrap(document["players"])

    cond do
      name == "" ->
        {nil, document}

      known = Enum.find(players, &(tile_name(&1) == name or &1["name"] == name)) ->
        {known["id"], document}

      true ->
        id = Enum.max([2_000_000 | Enum.map(players, &(&1["id"] || 0))]) + 1
        {id, Map.put(document, "players", players ++ [%{"id" => id, "name" => name}])}
    end
  end

  @doc """
  Gives a tournament pairings written in the shape of the results server's
  public snapshot - `tournament` (name, city), `players` by number, `rounds`
  whose boards name two numbers. It is what the demo makes up and what the
  tests plant; the box itself does not fetch such a thing any more.
  """
  def import_snapshot(%Tournament{} = tournament, %{} = snapshot) do
    players =
      for %{"no" => no} = p <- List.wrap(snapshot["players"]), is_integer(no) do
        p |> Map.take(~w(no name title rating federation fide_id)) |> Map.put("id", no)
      end

    rounds =
      for %{"number" => number} = round <- List.wrap(snapshot["rounds"]) do
        %{
          "number" => number,
          "boards" =>
            for %{"board" => board} = b <- List.wrap(round["boards"]), is_integer(board) do
              %{
                "game" => nil,
                "board" => board,
                "label" => to_string(board),
                "kind" => "game",
                "white" => b["white"],
                "black" => b["black"],
                "result" => b["result"]
              }
            end
        }
      end

    described = snapshot["tournament"] || %{}

    update(tournament, %{
      name: described["name"] || tournament.name,
      document:
        Jason.encode!(%{
          "tournament" => %{
            "name" => described["name"],
            "site" => described["city"],
            "city" => described["city"]
          },
          "players" => players,
          "rounds" => rounds
        }),
      document_at: DateTime.utc_now(:second)
    })
  end

  # --- connect codes -----------------------------------------------------------

  def links, do: Link |> order_by([l], l.id) |> Repo.all()
  def get_link(nil), do: nil
  def get_link(id), do: Repo.get(Link, id)

  @doc "The tournaments a code reaches, as the box holds them."
  def of_link(%Link{id: id}),
    do: Tournament |> where([t], t.link_id == ^id) |> order_by([t], t.id) |> Repo.all()

  def link_of(%Tournament{link_id: id}), do: get_link(id)
end
