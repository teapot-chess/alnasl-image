defmodule Alnasl.DataCase do
  @moduledoc """
  This module defines the setup for tests requiring
  access to the application's data layer.

  You may define functions here to be used as helpers in
  your tests.

  Finally, if the test case interacts with the database,
  we enable the SQL sandbox, so changes done to the database
  are reverted at the end of every test. If you are using
  PostgreSQL, you can even run database tests asynchronously
  by setting `use Alnasl.DataCase, async: true`, although
  this option is not recommended for other databases.
  """

  use ExUnit.CaseTemplate

  using do
    quote do
      alias Alnasl.Repo

      import Ecto
      import Ecto.Changeset
      import Ecto.Query
      import Alnasl.DataCase
    end
  end

  setup tags do
    Alnasl.DataCase.setup_sandbox(tags)
    :ok
  end

  @doc """
  Sets up the sandbox based on the test tags.
  """
  def setup_sandbox(tags) do
    pid = Ecto.Adapters.SQL.Sandbox.start_owner!(Alnasl.Repo, shared: not tags[:async])
    on_exit(fn -> Ecto.Adapters.SQL.Sandbox.stop_owner(pid) end)

    # The tests of the pages were written for every page, as an installation
    # that was in use before simple mode came along sees them. A test about
    # simple mode itself, which a new installation starts in, says so with
    # `@tag :simple_mode` (`AlnaslWeb.Mode`). Written without telling the
    # pages: nothing is listening yet.
    unless tags[:simple_mode] do
      Alnasl.Repo.insert!(%Alnasl.Settings.Setting{key: "ui_mode", value: ~s("full")})
    end

    :ok
  end

  @doc "The box's own tournament: where a test's results page, round and Lichess round are kept."
  def own, do: Alnasl.Tournaments.default()

  @doc "Changes the box's own tournament: `own_put(relay_key: \"orrk_wrong\")`."
  def own_put(attrs), do: Alnasl.Tournaments.update!(own(), Map.new(attrs))

  @doc """
  A helper that transforms changeset errors into a map of messages.

      assert {:error, changeset} = Accounts.create_user(%{password: "short"})
      assert "password is too short" in errors_on(changeset).password
      assert %{password: ["password is too short"]} = errors_on(changeset)

  """
  def errors_on(changeset) do
    Ecto.Changeset.traverse_errors(changeset, fn {message, opts} ->
      Regex.replace(~r"%{(\w+)}", message, fn _, key ->
        opts |> Keyword.get(String.to_existing_atom(key), key) |> to_string()
      end)
    end)
  end
end
