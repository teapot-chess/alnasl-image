# Releasing Polis

How a version gets from `main` to somebody's hall, what each downloaded
file is, and - because none of it has happened yet - what the first release
has to prove.

## Cutting a release

One commit on `main`:

1. `mix.exs`: the new `version:`.
2. `CHANGELOG.md`: rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD`
   (and start a new, empty `## [Unreleased]` above it).

Push. `.github/workflows/release.yml` builds every target, starts each one
and looks at its answer, and then - only if every target passed - tags
`vX.Y.Z` at that commit and publishes the release with the changelog
section as its notes.

It publishes when **both** are true: `mix.exs` names a version without a
GitHub release, and the changelog has a section for exactly that version.
A version without notes publishes nothing (the run says so in a notice and
stays green); so does a push that changes neither. That second condition is
the one difference from OpenPairings, where the version alone decides, and
it is there for one reason: **`main` says 0.1.0 today and no release
exists**, so without it the first push would have published 0.1.0 on the
spot.

Do not tag by hand. If you do, the tag must be `v` + the version in
`mix.exs`, or the workflow refuses.

There is no way to un-release. A wrong release is followed by a right one
with a higher number; installed copies move forward only.

## What a release holds

All names are without a version, so that
`https://github.com/teapot-chess/Polis/releases/latest/download/<name>`
is a link that stays right. The version is inside each file.

| File | What it is | Who asks for it by name |
|---|---|---|
| `Polis-Setup.exe` | The Windows installer (Velopack, per user, one click) | the download page |
| `polis-windows-x86_64-portable.zip` | The same release as a folder; installs nothing | the download page |
| `polis-linux-x86_64.tar.gz` | The Linux release, PCs | `install.sh`, `update.sh`, the download page |
| `polis-linux-aarch64.tar.gz` | The Linux release, 64-bit Raspberry Pi and other arm64 | the same |
| `polis-macos-aarch64.zip` | `Polis.app` for Apple Silicon (M1 and later), zipped with `ditto` | the download page; a Mac copy's update notice (its size) |
| `polis-macos-x86_64.zip` | `Polis.app` for Intel Macs (macOS 10.13 and newer), built only for a release | the same, on an Intel Mac |
| `install.sh` | The one-line installer | `curl ... \| sudo sh` |
| `update.sh`, `uninstall.sh` | Copies of what the archive carries, for reading | nobody; a person |
| `SHA256SUMS` | Checksums of everything above and below | `install.sh`, `update.sh` |
| `releases.win.json` | Velopack's feed: which Windows versions exist | every installed Windows copy |
| `PolisApp-X.Y.Z-full.nupkg` | The Windows program as Velopack fetches it | the same, via the feed |
| `PolisApp-X.Y.Z-delta.nupkg` | The difference from the release before (from the second release on) | the same |

Never rename `releases.win.json` or a `.nupkg`, and never change the pack
id `PolisApp`: installed copies look for those names, and one that cannot
find them stays on its version for ever without saying why.

## Where things are built from

| | |
|---|---|
| `mix.exs`, `releases/0` and `release_extras/1` | one release, `polis`; per system, the files beside `bin/` |
| `config/runtime.exs`, `lib/polis/data_home.ex` | where an installed copy keeps its data, and the refusal to keep it anywhere an installer owns |
| `rel/env.sh.eex`, `rel/env.bat.eex` | Erlang distribution off by default |
| `rel/windows/launcher.c` | `Polis.exe`: starts the release, opens the browser, is the stop button, applies an update |
| `priv/print/print.ps1` | the Windows road to a printer; CI parses it with Windows PowerShell, nothing runs it there |
| `rel/windows/build_launcher.ps1` | compiles it with `zig cc` (run by `mix release`) |
| `rel/windows/build_installer.ps1` | `vpk pack`, with the checks that keep data out of harm's way |
| `rel/windows/build_icon.py` | draws `Polis.ico` from the mark; run by hand when the mark changes |
| `rel/linux/install.sh`, `update.sh`, `uninstall.sh` | the Linux installation |
| `rel/linux/polis.service`, `polis-update.path`, `polis-update.service` | the service, and the root-owned updater a page can ask but not command |
| `rel/macos/build_app.sh`, `launcher.sh`, `Info.plist` | `Polis.app` around the release: its launcher (status window, Stop), the checks that it links nothing but the system |
| `rel/macos/sign_and_notarize.sh`, `entitlements.plist` | Developer ID signing and notarisation, once the Apple account exists (below) |
| `lib/polis/updates.ex`, `updates/checker.ex` | the check, the notice, the refusal while a sheet prints, the hand-over |
| `tools/release_notes.sh` | the changelog section of one version |

## Signing the Mac app

The macOS jobs sign `Polis.app` with the Developer ID Application
certificate and the hardened runtime, notarise it with Apple, staple the
ticket and check it with `spctl` before the zip is made. A build without
the secrets (a fork) skips all of that with a warning and ships ad-hoc
signed. The secrets belong to the `teapot-chess` organisation, so every
repository in it has them:

| Secret | What |
|---|---|
| `MACOS_CERT_P12` | the *Developer ID Application* certificate with its private key and the intermediate, exported as `.p12`, then base64 |
| `MACOS_CERT_PASSWORD` | the `.p12`'s password |
| `APPLE_TEAM_ID` | the ten-character team id |
| `ASC_KEY_ID` | the App Store Connect API key's id |
| `ASC_ISSUER_ID` | the API key's issuer id |
| `ASC_KEY_P8` | the API key's `.p8` file, base64 |

`rel/macos/sign_and_notarize.sh` signs every binary with the hardened
runtime and the BEAM's entitlements, notarises with the API key, staples,
and asks Gatekeeper. The temporary keychain is deleted at the end of the
job, whatever happened.

To test the signing without releasing anything, start the workflow by hand
on a branch with **mac_only**: it builds and notarises the Mac apps and
publishes nothing.

## Building one by hand

Windows, with Elixir, `zig` and `vpk` (`dotnet tool install -g vpk
--version 1.2.0`) on the PATH. Set `POLIS_DATA` to a scratch folder first:
any `MIX_ENV=prod` task reads the runtime configuration, and without it
would create the real data folder of the PC you are sitting at.

```
set MIX_ENV=prod
set POLIS_DATA=%CD%\tmp\release-data
mix deps.get --only prod
mix compile
mix release polis --overwrite
.\rel\windows\build_installer.ps1 -PayloadDir _build\prod\rel\polis -OutputDir installer_out
```

There is no asset build: the page's CSS and script are in `priv/static`
as written, and Phoenix's own scripts come from their packages.

Linux: the same three `mix` lines, then
`tar -czf polis-linux-$(uname -m).tar.gz -C _build/prod/rel polis`. Built
on your machine it runs on your machine's glibc or newer; the workflow
builds on Ubuntu 22.04 for a reason.

**Building an installer is harmless. Running one is not a test to do on the
PC you work on.** Use a Windows Sandbox or a spare machine. This project's
sister lost real data to an installer run "just to see".

## What the first release has to prove

Nothing below has been done. Each line is a claim the code makes and nobody
has watched come true. Work down the list with the first release and strike
what holds.

**The workflow**

- [ ] `ci.yml` and `release.yml` parse and run at all. (They are
      Alnasl's, which do, with the serial parts taken out and the print
      script put in.)
- [ ] `print.ps1` parses under Windows PowerShell 5.1 on `windows-latest`.
- [ ] `shellcheck --severity=warning` passes on `rel/linux/*.sh` (it was
      not available where they were written; they pass `sh -n`).
- [ ] The smoke tests pass on all three targets, including "the release
      writes a PDF" and "nothing listens but 127.0.0.1:4166".
- [ ] A push with a version and no changelog section publishes nothing; a
      push with both publishes once; the next push publishes nothing.
- [ ] The release notes are the changelog section.

**Windows**

- [ ] `Polis-Setup.exe` installs to `%LOCALAPPDATA%\PolisApp`, makes the
      Start menu and desktop entries, and starts the launcher.
- [ ] The launcher's window appears, the browser opens when the site
      answers, a second double-click opens a tab instead of a second server.
- [ ] Closing the window asks, and stops the program; no `erl.exe` is left.
- [ ] The data is in `%LOCALAPPDATA%\PolisData`, and **is still there
      after uninstalling**. This is the one that matters. Join a
      tournament first.
- [ ] Installing again finds the data.
- [ ] A PC that never had Erlang or the Visual C++ runtime starts it (the
      three DLLs beside `erl.exe` are there for this).
- [ ] The printer list shows the PC's printers; "Test print" on a real
      printer prints the frame whole, on A4 and on Letter; a round with an
      accented and a Cyrillic name prints both as they are.
- [ ] The place cards fold into tents that read the right way up on both
      sides.
- [ ] From the second release on: the notice appears, "Download and
      install" stops the program, the launcher downloads and applies, the
      new version starts. Then the unhappy ways: no network at that moment
      (the old version must come back), and a sheet printing (must
      refuse).
- [ ] SmartScreen says what the README says it says.
- [ ] Symantec and Defender leave `Setup.exe`, the portable zip and the
      installed `Polis.exe` alone. (Measured for OpenPairings' Velopack
      installer and portable release on this network; assumed to carry
      over.)
- [ ] "Start with Windows" starts it, minimised, without a browser.

**Linux**

- [ ] `install.sh` on Debian 12, Ubuntu 22.04 and Raspberry Pi OS Bookworm
      64-bit: user, group, directories, units, service up.
- [ ] The hardened unit starts at all (`ProtectSystem=strict`,
      `RELEASE_TMP=/run/polis`, `RestrictAddressFamilies`), and `lp` from
      inside it reaches CUPS (the socket in `/run/cups`).
- [ ] `update.sh` to a newer release: download, checksum, switch, restart,
      answer. And to a release that does not start: the old one is back.
- [ ] "Download and install" on the page: the request file appears,
      `polis-update.path` fires, the page comes back on the new version.
- [ ] `uninstall.sh` removes the program and **leaves `/var/lib/polis`**.
- [ ] Offline install from an unpacked archive.

**macOS** (the full list, for a person with a Mac, is in `docs/macos.md`)

- [ ] `macos-15` builds it, `build_app.sh` finds no
      Homebrew library, and the app starts from a read-only bundle on the
      runner.
- [ ] Downloaded on a real Mac, it opens with no question, shows its
      window, opens the browser; Stop asks and stops; no `beam` is left.
- [ ] The data is in `~/Library/Application Support/PolisData`, and is
      still there after the app is binned.
- [ ] The Mac's printers are listed (CUPS is part of macOS) and a test
      page prints.

## Version numbers

`0.1.0` is in `mix.exs` and has never been released, so the first release
can simply be `0.1.0`: no bump, only the changelog heading. From then on:
patch for fixes, minor for anything an arbiter would notice, and 1.0.0 the
day a whole tournament has had its pairings printed by an installed copy
without anybody touching it.
