defmodule ArkabWeb.StatusLive do
  @moduledoc """
  The bridge's page. Read once a second, because what it shows - a line up
  or down, events waiting - changes on its own. In English or Dutch
  (`ArkabWeb.Words`); the help is `ArkabWeb.HelpLive`.

  Anyone on the hall's network may look; only the machine itself may touch,
  or a browser unlocked with the remote PIN (`ArkabWeb.Local.may_change?/2`,
  `ArkabWeb.Pin`). The peer is read from the socket when the page mounts
  (`local?`), the PIN grant from the session, and every event that changes
  something asks again on the server, whatever the page drew: a button that is
  not drawn is still an event anybody can send. The PIN itself is set, changed
  and removed from this machine only (`local?`, never the grant).
  """

  use ArkabWeb, :live_view

  import ArkabWeb.Components, only: [foot: 1, logo: 1]

  alias Arkab.{Autostart, Box, Help, Updates}
  alias ArkabWeb.{Local, Pin, Words}

  # Everything that changes something. The rest of the events are none.
  @changing ~w(join update later update_check check_now autostart remove)
  # The PIN's own: this machine only, a grant is not enough.
  @local_only ~w(pin_set pin_remove help upgrade_open upgrade_cancel upgrade switch_open switch_cancel switch)

  @impl true
  def mount(_params, session, socket) do
    if connected?(socket) do
      :timer.send_interval(1_000, :refresh)
      Phoenix.PubSub.subscribe(Arkab.PubSub, Updates.topic())
    end

    {:ok,
     socket
     |> assign(
       joining?: false,
       message: nil,
       update_message: nil,
       checking?: false,
       local?: Local.local_socket?(socket),
       grant: session[Pin.session_key()],
       pin_message: nil,
       helping?: false,
       help: nil,
       box: nil,
       box_polling?: false,
       box_tick: 0,
       upgrade_confirm?: false,
       upgrade_message: nil,
       switch_confirm?: false,
       switch_message: nil
     )
     |> assign_access()
     |> load()
     |> first_poll()}
  end

  # The first answer of the box's setup server comes with the page, not a tick later.
  defp first_poll(socket), do: if(connected?(socket), do: poll_box(socket, true), else: socket)

  @impl true
  def handle_info(:refresh, socket),
    do: {:noreply, socket |> assign_access() |> load() |> poll_box()}

  def handle_info(:update_changed, socket), do: {:noreply, load(socket)}
  def handle_info(_other, socket), do: {:noreply, socket}

  @impl true
  def handle_event(event, params, socket) when event in @changing or event in @local_only do
    socket = assign_access(socket)

    allowed? =
      if event in @local_only, do: socket.assigns.local?, else: socket.assigns.may_change?

    if allowed?, do: change(event, params, socket), else: {:noreply, socket}
  end

  def handle_event(_event, _params, socket), do: {:noreply, socket}

  defp change("join", %{"link" => link}, socket) do
    {:noreply,
     socket
     |> assign(joining?: true, message: nil)
     |> start_async(:join, fn -> Arkab.Bridge.join(link) end)}
  end

  defp change("update", _params, socket) do
    case Updates.apply() do
      :ok -> {:noreply, assign(socket, update_message: {:ok, :update_started})}
      {:error, _reason} -> {:noreply, assign(socket, update_message: nil) |> load()}
    end
  end

  defp change("later", %{"version" => version}, socket) do
    Updates.later(version)
    {:noreply, load(socket)}
  end

  defp change("update_check", params, socket) do
    Updates.put_mode(if(params["on"] == "true", do: "ask", else: "never"))
    {:noreply, load(socket)}
  end

  defp change("check_now", _params, socket) do
    {:noreply,
     socket
     |> assign(checking?: true, update_message: nil)
     |> start_async(:check, fn -> Updates.Checker.check_now() end)}
  end

  defp change("autostart", params, socket) do
    case Autostart.set(params["on"] == "true") do
      :ok -> {:noreply, load(socket)}
      {:error, _words} -> {:noreply, assign(socket, update_message: {:error, :autostart_failed})}
    end
  end

  defp change("remove", %{"id" => id}, socket) do
    with {id, ""} <- Integer.parse(id), do: Arkab.Bridge.remove(id)
    {:noreply, load(socket)}
  end

  # Sends the report through the box's setup server. This machine only: a report leaves the box.
  defp change("help", _params, socket) do
    if socket.assigns.helping? or not Help.available?() do
      {:noreply, socket}
    else
      {:noreply,
       socket |> assign(helping?: true, help: nil) |> start_async(:help, fn -> Help.request() end)}
    end
  end

  defp change("upgrade_open", _params, socket),
    do: {:noreply, assign(socket, upgrade_confirm?: offer(socket) != nil, upgrade_message: nil)}

  defp change("upgrade_cancel", _params, socket),
    do: {:noreply, assign(socket, upgrade_confirm?: false)}

  # The train comes from what the box offered, never from the browser.
  defp change("upgrade", _params, socket) do
    case offer(socket) do
      nil ->
        {:noreply, assign(socket, upgrade_confirm?: false)}

      %{train: train} ->
        {:noreply,
         socket
         |> assign(upgrade_confirm?: false, upgrade_message: nil)
         |> start_async(:upgrade, fn -> Box.upgrade(train) end)}
    end
  end

  defp change("switch_open", _params, socket),
    do: {:noreply, assign(socket, switch_confirm?: slave?(socket), switch_message: nil)}

  defp change("switch_cancel", _params, socket),
    do: {:noreply, assign(socket, switch_confirm?: false)}

  defp change("switch", _params, socket) do
    if slave?(socket) do
      {:noreply,
       socket
       |> assign(switch_confirm?: false, switch_message: nil)
       |> start_async(:switch, fn -> Box.switch_mode("master") end)}
    else
      {:noreply, assign(socket, switch_confirm?: false)}
    end
  end

  defp change("pin_set", %{"pin" => pin}, socket) do
    message =
      case Pin.set(pin) do
        :ok -> {:ok, :pin_saved}
        {:error, _short} -> {:error, :pin_short}
      end

    {:noreply, socket |> assign(pin_message: message) |> assign_access()}
  end

  defp change("pin_remove", _params, socket) do
    Pin.remove()
    {:noreply, socket |> assign(pin_message: {:ok, :pin_removed}) |> assign_access()}
  end

  @impl true
  def handle_async(:check, {:ok, answer}, socket) do
    message =
      case answer do
        {:ok, _info} -> nil
        :current -> {:ok, :up_to_date}
        :error -> {:error, :check_failed}
      end

    {:noreply, socket |> assign(checking?: false, update_message: message) |> load()}
  end

  def handle_async(:help, {:ok, {:ok, sent}}, socket),
    do: {:noreply, assign(socket, helping?: false, help: {:ok, sent})}

  def handle_async(:help, {:ok, {:error, reason}}, socket),
    do: {:noreply, assign(socket, helping?: false, help: {:error, reason})}

  def handle_async(:help, {:exit, _reason}, socket),
    do: {:noreply, assign(socket, helping?: false, help: {:error, :unavailable})}

  def handle_async(:upgrade, {:ok, :ok}, socket),
    do: {:noreply, socket |> assign(upgrade_message: {:ok, :upgrade_started}) |> poll_box(true)}

  def handle_async(:upgrade, {:ok, {:error, reason}}, socket),
    do: {:noreply, assign(socket, upgrade_message: {:error, upgrade_error_key(reason)})}

  def handle_async(:upgrade, {:exit, _reason}, socket),
    do: {:noreply, assign(socket, upgrade_message: {:error, :upgrade_unavailable})}

  def handle_async(:switch, {:ok, :ok}, socket),
    do: {:noreply, assign(socket, switch_message: {:ok, :switch_started})}

  def handle_async(:switch, {:ok, {:error, _reason}}, socket),
    do: {:noreply, assign(socket, switch_message: {:error, :switch_failed})}

  def handle_async(:switch, {:exit, _reason}, socket),
    do: {:noreply, assign(socket, switch_message: {:error, :switch_failed})}

  def handle_async(:box, {:ok, {:ok, box}}, socket),
    do: {:noreply, assign(socket, box: box, box_polling?: false)}

  def handle_async(:box, _other, socket), do: {:noreply, assign(socket, box_polling?: false)}

  def handle_async(:check, {:exit, _reason}, socket),
    do: {:noreply, assign(socket, checking?: false, update_message: {:error, :check_failed})}

  def handle_async(:join, {:ok, {:ok, _id}}, socket),
    do:
      {:noreply,
       socket
       |> assign(joining?: false, message: {:ok, Words.t(socket.assigns.locale, :joined)})
       |> load()}

  def handle_async(:join, {:ok, {:error, reason}}, socket),
    do:
      {:noreply,
       assign(socket, joining?: false, message: {:error, words(reason, socket.assigns.locale)})}

  def handle_async(:join, {:exit, _reason}, socket),
    do:
      {:noreply,
       assign(socket,
         joining?: false,
         message: {:error, words(:unreachable, socket.assigns.locale)}
       )}

  defp words(:not_a_link, locale), do: Words.t(locale, :err_not_a_link)
  defp words(:used_or_expired, locale), do: Words.t(locale, :err_used_or_expired)
  defp words(:unreachable, locale), do: Words.t(locale, :err_unreachable)
  defp words(:version, locale), do: Words.t(locale, :err_version)
  defp words(:elsewhere, locale), do: Words.t(locale, :err_elsewhere)
  defp words(_other, locale), do: Words.t(locale, :err_other)

  defp load(socket) do
    status =
      try do
        Arkab.Bridge.status()
      catch
        :exit, _reason ->
          %{
            name: "",
            servers: [],
            waiting: 0,
            store: %{dropped: 0, error: nil},
            ports: [],
            boards: [],
            recording?: false
          }
      end

    assign(socket,
      status: status,
      notice: Updates.notice(),
      install_kind: Updates.install_kind(),
      update_mode: Updates.mode(),
      last_update: Updates.last_result(),
      autostart?: Autostart.supported?() and Autostart.enabled?()
    )
  end

  # Asked again on every tick and every change: a PIN that was changed or a
  # grant that ran out takes the buttons away from a page that is still open.
  defp assign_access(socket) do
    may_change? = Local.may_change?(socket.assigns.local?, socket.assigns.grant)
    pin_set? = Pin.set?()

    assign(socket,
      may_change?: may_change?,
      pin_offered?: not may_change? and pin_set?,
      pin_set?: pin_set?,
      unlocked?: not socket.assigns.local? and Pin.valid_grant?(socket.assigns.grant)
    )
  end

  # Asks the box's setup server how the image and the mode stand: every 5 seconds, every second while
  # an upgrade runs (the progress bar). Not at all where there is no such server, nor for a visitor who
  # may not use the answer. Asked off the page's process: the server may be slow.
  defp poll_box(socket, force? \\ false) do
    tick = socket.assigns.box_tick + 1
    socket = assign(socket, box_tick: tick)

    cond do
      not socket.assigns.local? or not Box.available?() ->
        socket

      socket.assigns.box_polling? ->
        socket

      force? or upgrading?(socket) or rem(tick, 5) == 1 ->
        socket |> assign(box_polling?: true) |> start_async(:box, &Box.snapshot/0)

      true ->
        socket
    end
  end

  defp upgrading?(%{assigns: %{box: %{system: %{busy?: busy?}}}}), do: busy?
  defp upgrading?(_socket), do: false

  defp offer(%{assigns: %{box: %{system: %{offer: offer}}}}), do: offer
  defp offer(_socket), do: nil

  defp slave?(%{assigns: %{box: %{mode: "slave"}}}), do: true
  defp slave?(_socket), do: false

  defp upgrade_error_key(:busy), do: :upgrade_busy
  defp upgrade_error_key(:updates_off), do: :upgrade_updates_off
  defp upgrade_error_key(:not_ab), do: :upgrade_not_ab
  defp upgrade_error_key(:bad_train), do: :upgrade_bad_train
  defp upgrade_error_key(:unavailable), do: :upgrade_unavailable
  defp upgrade_error_key(_other), do: :upgrade_server_error

  defp phase_key("downloading"), do: :phase_downloading
  defp phase_key("verifying"), do: :phase_verifying
  defp phase_key("installing"), do: :phase_installing
  defp phase_key("restarting"), do: :phase_restarting
  defp phase_key("waiting"), do: :phase_waiting
  defp phase_key(_other), do: :phase_working

  defp help_error_key(reason), do: String.to_existing_atom("help_" <> Atom.to_string(reason))

  defp help_until(iso) do
    case DateTime.from_iso8601(iso) do
      {:ok, at, _offset} -> Calendar.strftime(at, "%Y-%m-%d %H:%M UTC")
      _ -> iso
    end
  end

  defp megabytes(bytes), do: :erlang.float_to_binary(bytes / 1_048_576, decimals: 1)

  @impl true
  def render(assigns) do
    ~H"""
    <main id="bridge">
      <header>
        <h1><.logo /> Arkab <span class="name">{@status.name}</span></h1>

        <p class="note">{Words.t(@locale, :tagline)}</p>
      </header>

      <section :if={!@may_change?} id="read-only">
        <h2>{Words.t(@locale, :read_only_title)}</h2>

        <p>{Words.t(@locale, :read_only)}</p>

        <p :if={@pin_offered?}>{Words.t(@locale, :read_only_pin)}</p>

        <p :if={@pin_offered?}>
          <a id="enter-pin" href="/unlock">{Words.t(@locale, :enter_pin)}</a>
        </p>
      </section>

      <section :if={@unlocked?} id="unlocked">
        <p class="note">{Words.t(@locale, :unlocked_note)}</p>

        <p><a id="lock-link" href="/lock">{Words.t(@locale, :lock_again)}</a></p>
      </section>

      <section :if={@notice} id="update">
        <h2>{Words.t(@locale, :update_available, version: @notice.version)}</h2>

        <p :if={@notice.size} class="note">
          {Words.t(@locale, :update_size, mb: megabytes(@notice.size))}
        </p>

        <p :if={@install_kind != :manual} class="note">{Words.t(@locale, :update_cost)}</p>

        <p :if={@install_kind == :manual && !@notice.no_build} class="note">
          {Words.t(@locale, :update_manual)}
        </p>

        <p :if={@notice.no_build} class="note">{Words.t(@locale, :update_no_build)}</p>

        <form :if={@may_change?} id="update-form" phx-submit="update">
          <button :if={@install_kind != :manual} id="update-button" type="submit">
            {Words.t(@locale, :update_install)}
          </button>

          <a
            :if={@install_kind == :manual && !@notice.no_build}
            id="update-link"
            href={@notice.url}
            rel="noopener"
          >
            {Words.t(@locale, :update_releases)}
          </a>

          <button
            id="update-later"
            type="button"
            phx-click="later"
            phx-value-version={@notice.version}
          >
            {Words.t(@locale, :update_later)}
          </button>
        </form>
      </section>

      <p
        :if={match?({:failed, _, _}, @last_update)}
        id="update-failed"
        class="error"
      >
        {Words.t(@locale, :update_failed,
          version: elem(@last_update, 1),
          why: elem(@last_update, 2)
        )}
      </p>

      <section id="servers">
        <h2>{Words.t(@locale, :servers)}</h2>

        <ul :if={@status.servers != []} id="server-list">
          <li :for={server <- @status.servers} id={"server-#{server.id}"}>
            <span
              class={["dot", if(server.up?, do: "up", else: "down")]}
              title={
                if(server.up?,
                  do: Words.t(@locale, :connected),
                  else: Words.t(@locale, :not_connected)
                )
              }
            ></span> <span class="server-name">{server.name}</span>
            <span :if={!server.up? && server.error} class="note">{server.error}</span>
            <button
              :if={@may_change?}
              id={"remove-#{server.id}"}
              type="button"
              phx-click="remove"
              phx-value-id={server.id}
              data-confirm={Words.t(@locale, :confirm_remove)}
            >
              {Words.t(@locale, :remove)}
            </button>
          </li>
        </ul>

        <p :if={@status.servers == []} class="note" id="no-servers">
          {Words.t(@locale, :no_servers)}
        </p>

        <p id="waiting">{Words.t(@locale, :waiting)} <strong>{@status.waiting}</strong></p>

        <p :if={@status.store.dropped > 0} id="store-dropped" class="error">
          {Words.t(@locale, :store_dropped, n: @status.store.dropped)}
        </p>

        <p :if={@status.store.error} id="store-error" class="error">
          {Words.t(@locale, :store_error, why: @status.store.error)}
        </p>
      </section>

      <section :if={@may_change?} id="join">
        <h2>{Words.t(@locale, :join_title)}</h2>

        <form id="join-form" phx-submit="join">
          <input
            id="join-link"
            type="text"
            name="link"
            placeholder="https://server/join/K7Q-4MD"
            autocomplete="off"
          />
          <button id="join-button" type="submit" disabled={@joining?}>
            {if @joining?, do: Words.t(@locale, :joining), else: Words.t(@locale, :join)}
          </button>

          <button id="scan-button" type="button" phx-hook="Scan" hidden>
            {Words.t(@locale, :scan)}
          </button>
        </form>
        <video id="scan-video" phx-update="ignore" hidden playsinline></video>
        <p :if={@message} id="join-message" class={elem(@message, 0)}>{elem(@message, 1)}</p>

        <p class="note">{Words.t(@locale, :join_hint)}</p>
      </section>

      <section id="ports">
        <h2>{Words.t(@locale, :ports_title)}</h2>

        <p :if={@status.ports == []} class="note">{Words.t(@locale, :no_ports)}</p>

        <ul id="port-list">
          <li :for={port <- @status.ports} id={"port-#{port.port}"}>
            <span class="mono">{port.port}</span> <span class="note">{port.description}</span>
            <span :if={!port.read?} class="note">{Words.t(@locale, :not_read)}</span>
            <ul>
              <li
                :for={board <- Enum.filter(@status.boards, &(&1.port == port.port))}
                id={"board-#{board.id}"}
              >
                <span class={["dot", if(board.connected?, do: "up", else: "down")]}></span> {if board.address,
                  do: Words.t(@locale, :board_no, n: board.address),
                  else: Words.t(@locale, :board)}
                <span :if={board.info[:serial]} class="mono">
                  {Words.t(@locale, :serial)} {board.info[:serial]}
                </span>
              </li>
            </ul>
          </li>
        </ul>

        <p class="note">
          {Words.t(@locale, :recording)} {if @status.recording?,
            do: Words.t(@locale, :on),
            else: Words.t(@locale, :off)}
        </p>
      </section>

      <section id="program">
        <h2>{Words.t(@locale, :program_title)}</h2>

        <p class="note">
          {Words.t(@locale, :version)} <span class="mono">{Updates.current_version()}</span>
        </p>

        <p :if={@may_change?}>
          <label>
            <input
              id="update-check"
              type="checkbox"
              checked={@update_mode == "ask"}
              phx-click="update_check"
              phx-value-on={to_string(@update_mode != "ask")}
            /> {Words.t(@locale, :update_check)}
          </label>
        </p>

        <p :if={@may_change? and Autostart.supported?()}>
          <label>
            <input
              id="autostart"
              type="checkbox"
              checked={@autostart?}
              phx-click="autostart"
              phx-value-on={to_string(!@autostart?)}
            /> {Words.t(@locale, :autostart)}
          </label>
        </p>

        <p :if={@may_change?}>
          <button id="check-now" type="button" phx-click="check_now" disabled={@checking?}>
            {if @checking?, do: Words.t(@locale, :checking), else: Words.t(@locale, :check_now)}
          </button>

          <span :if={@update_message} id="update-message" class={elem(@update_message, 0)}>
            {Words.t(@locale, elem(@update_message, 1))}
          </span>
        </p>

        <div :if={@local? and Help.available?()} id="help">
          <h3>{Words.t(@locale, :help_title)}</h3>

          <p class="note">{Words.t(@locale, :help_hint)}</p>

          <p>
            <button id="help-send" type="button" phx-click="help" disabled={@helping?}>
              {if @helping?, do: Words.t(@locale, :help_sending), else: Words.t(@locale, :help_send)}
            </button>
          </p>

          <div :if={match?({:ok, _}, @help)} id="help-result">
            <p class="note">{Words.t(@locale, :help_code)}</p>

            <p id="help-code" style="font-size: 2.6em; font-weight: 700; letter-spacing: 0.08em;">
              {Help.format_code(elem(@help, 1).code)}
            </p>

            <p>{Words.t(@locale, :help_read, until: help_until(elem(@help, 1).expires_at))}</p>
          </div>

          <p :if={match?({:error, _}, @help)} id="help-error" class="error">
            {Words.t(@locale, help_error_key(elem(@help, 1)))}
          </p>
        </div>

        <div :if={@local? and Box.available?() and @box} id="box">
          <h3>{Words.t(@locale, :box_title)}</h3>

          <p class="note" id="box-version">
            {Words.t(@locale, :box_image,
              train: @box.system.train,
              version: @box.system.version
            )}
          </p>

          <section :if={@box.system.offer && !@box.system.busy?} id="upgrade-card">
            <h4>{Words.t(@locale, :upgrade_available, train: @box.system.offer.train)}</h4>

            <p :if={@box.system.offer.notes != ""} class="note" id="upgrade-notes">
              {@box.system.offer.notes}
            </p>

            <p class="note">{Words.t(@locale, :upgrade_explain)}</p>

            <p :if={!@box.system.updates_on?} id="upgrade-off" class="error">
              {Words.t(@locale, :upgrade_updates_off)}
            </p>

            <p :if={!@upgrade_confirm?}>
              <button
                id="upgrade-open"
                type="button"
                phx-click="upgrade_open"
                disabled={!@box.system.updates_on?}
              >
                {Words.t(@locale, :upgrade_button, train: @box.system.offer.train)}
              </button>
            </p>

            <div :if={@upgrade_confirm?} id="upgrade-confirm">
              <p>{Words.t(@locale, :upgrade_confirm, train: @box.system.offer.train)}</p>

              <p>
                <button id="upgrade-yes" type="button" phx-click="upgrade">
                  {Words.t(@locale, :upgrade_yes, train: @box.system.offer.train)}
                </button>

                <button id="upgrade-no" type="button" phx-click="upgrade_cancel">
                  {Words.t(@locale, :cancel)}
                </button>
              </p>
            </div>
          </section>

          <p
            :if={!@box.system.offer && @box.system.offer_blocked}
            id="upgrade-blocked"
            class="note"
          >
            {Words.t(@locale, :upgrade_blocked, version: @box.system.offer_blocked)}
          </p>

          <div :if={@box.system.busy?} id="upgrade-progress">
            <p>
              {Words.t(@locale, phase_key(@box.system.phase))}
              <span :if={@box.system.progress} id="upgrade-percent">{@box.system.progress}%</span>
            </p>
            <progress :if={@box.system.progress} max="100" value={@box.system.progress}></progress>
            <p class="note">{Words.t(@locale, :upgrade_keep_power)}</p>
          </div>

          <p :if={@box.system.request_error == "round_in_progress"} id="upgrade-round" class="error">
            {Words.t(@locale, :upgrade_round)}
          </p>

          <p :if={@upgrade_message} id="upgrade-message" class={elem(@upgrade_message, 0)}>
            {Words.t(@locale, elem(@upgrade_message, 1))}
          </p>

          <div :if={@box.mode == "slave"} id="mode-card">
            <h4>{Words.t(@locale, :mode_slave)}</h4>

            <p class="note">{Words.t(@locale, :mode_slave_hint)}</p>

            <p :if={!@switch_confirm?}>
              <button id="switch-open" type="button" phx-click="switch_open">
                {Words.t(@locale, :switch_button)}
              </button>
            </p>

            <div :if={@switch_confirm?} id="switch-confirm">
              <p>{Words.t(@locale, :switch_confirm)}</p>

              <p>
                <button id="switch-yes" type="button" phx-click="switch">
                  {Words.t(@locale, :switch_yes)}
                </button>

                <button id="switch-no" type="button" phx-click="switch_cancel">
                  {Words.t(@locale, :cancel)}
                </button>
              </p>
            </div>

            <p :if={@switch_message} id="switch-message" class={elem(@switch_message, 0)}>
              {Words.t(@locale, elem(@switch_message, 1))}
            </p>
          </div>
        </div>

        <div :if={@local?} id="pin">
          <h3>{Words.t(@locale, :pin_title)}</h3>

          <p class="note">
            {if @pin_set?,
              do: Words.t(@locale, :pin_is_set),
              else: Words.t(@locale, :pin_is_not_set)}
          </p>

          <form id="pin-form" phx-submit="pin_set">
            <input
              id="pin-input"
              type="password"
              name="pin"
              autocomplete="new-password"
              placeholder={Words.t(@locale, :pin_new)}
              aria-label={Words.t(@locale, :pin_new)}
            /> <button id="pin-save" type="submit">{Words.t(@locale, :pin_save)}</button>
            <button :if={@pin_set?} id="pin-remove" type="button" phx-click="pin_remove">
              {Words.t(@locale, :pin_remove)}
            </button>
          </form>

          <p :if={@pin_message} id="pin-message" class={elem(@pin_message, 0)}>
            {Words.t(@locale, elem(@pin_message, 1))}
          </p>

          <p class="note">{Words.t(@locale, :pin_hint)}</p>

          <p class="note">{Words.t(@locale, :pin_plain)}</p>
        </div>
      </section>
      <.foot locale={@locale} page={:status} />
    </main>
    """
  end
end
