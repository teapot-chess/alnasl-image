defmodule Arkab.ReleaseFilesTest do
  @moduledoc """
  The files a release is made of and by, held to each other: the names the
  workflow publishes are the names the program, the scripts and the download
  page ask for; every action is pinned to a commit; the changelog has
  something to say about the version in `mix.exs`, or says it is unreleased.

  None of this runs a workflow. It catches the kind of mistake that is one
  renamed file in one of five places.
  """

  use ExUnit.Case, async: true

  alias Arkab.Updates

  @root Path.expand("../..", __DIR__)

  defp read(path), do: File.read!(Path.join(@root, path))

  defp version, do: Mix.Project.config()[:version]

  describe "the workflows" do
    test "every action is pinned to a commit, with the version beside it" do
      for file <- ~w(.github/workflows/ci.yml .github/workflows/release.yml),
          [line] <- Regex.scan(~r/^.*\buses:.*$/m, read(file)) do
        assert line =~ ~r/uses: [\w.-]+\/[\w.\/-]+@[0-9a-f]{40} # v\d+\.\d+\.\d+$/,
               "#{file}: not pinned to a commit: #{String.trim(line)}"
      end
    end

    test "only the job that publishes may write" do
      workflow = read(".github/workflows/release.yml")
      assert length(Regex.scan(~r/contents: write/, workflow)) == 1
      assert workflow =~ ~r/^permissions:\n  contents: read$/m
      refute read(".github/workflows/ci.yml") =~ "contents: write"
    end

    test "the files it publishes are the files that are asked for by name" do
      workflow = read(".github/workflows/release.yml")
      brief = read("docs/download-page-brief.md")
      readme = read("README.md")

      # What the program computes the size of...
      assert Updates.asset_name(:velopack, "1.2.3") == "ArkabApp-1.2.3-full.nupkg"
      assert workflow =~ "ArkabApp-${VERSION}-full.nupkg"

      # ...what the Linux scripts download...
      for script <- ~w(rel/linux/install.sh rel/linux/update.sh) do
        assert read(script) =~ ~s(file="arkab-linux-$cpu.tar.gz")
        assert read(script) =~ "SHA256SUMS"
      end

      # ...and every fixed name, in the workflow's own list of what a
      # release must hold, on the download page's brief and in the README.
      for name <- ~w(Arkab-Setup.exe arkab-windows-x86_64-portable.zip
                     arkab-linux-x86_64.tar.gz arkab-linux-aarch64.tar.gz install.sh
                     arkab-macos-aarch64.zip arkab-macos-x86_64.zip) do
        assert workflow =~ name, "release.yml does not publish #{name}"
        assert brief =~ "releases/latest/download/#{name}", "the brief does not link #{name}"
      end

      assert readme =~ "releases/latest/download/Arkab-Setup.exe"
      assert readme =~ "releases/latest/download/install.sh"
      assert readme =~ "releases/latest/download/arkab-macos-aarch64.zip"
      assert workflow =~ "releases.win.json"
      assert workflow =~ "SHA256SUMS"
    end

    test "the Linux archives are built where a Raspberry Pi can run them" do
      workflow = read(".github/workflows/release.yml")
      assert workflow =~ ~s("runner":"ubuntu-22.04","target":"linux-x86_64")
      assert workflow =~ ~s("runner":"ubuntu-22.04-arm","target":"linux-aarch64")
    end

    test "the Mac app is built on the Macs whose names the release gives it" do
      workflow = read(".github/workflows/release.yml")
      assert workflow =~ ~s("runner":"macos-15","target":"macos-aarch64","macos_min":"11.0")
      # The Intel build is made for a release or a hand-started run, never
      # for an ordinary push: the plan job adds it.
      assert workflow =~ ~s("runner":"macos-15-intel","target":"macos-x86_64","macos_min":"10.13")
      assert workflow =~ ~s(if [ "$PUBLISH" = true ] || [ "$EVENT" = workflow_dispatch ])
      assert workflow =~ ~s(dist/arkab-${{ matrix.target }}.zip)
      # Signing is there, and cannot run without its secret.
      assert workflow =~ "if: runner.os == 'macOS' && steps.apple.outputs.sign == 'true'"
      # ...and install.sh refuses, in words, a system older than that.
      assert read("rel/linux/install.sh") =~ ~s([ "$minor" -lt 35 ])
    end
  end

  describe "the Mac runtime" do
    test "is built for the target's oldest macOS, and a build that is not fails" do
      workflow = read(".github/workflows/release.yml")
      build_otp = read("rel/macos/build_otp.sh")
      build_app = read("rel/macos/build_app.sh")

      # The ready-made Erlang for macOS said "15.0"; it is not used there.
      assert workflow =~ "if: runner.os != 'macOS'"
      assert workflow =~ ~s(sh rel/macos/build_otp.sh "$HOME/otp-macos")

      assert workflow =~
               ~s(echo "MACOSX_DEPLOYMENT_TARGET=${{ matrix.macos_min }}" >> "$GITHUB_ENV")

      assert workflow =~ "steps.otp-cache.outputs.cache-hit != 'true'"

      assert [_, otp_key] = Regex.run(~r/path: ~\/otp-macos\n\s+key: (.+)$/m, workflow)

      for part <- ~w(env.OTP_VERSION env.OPENSSL_VERSION env.ELIXIR_VERSION
                     env.MACOSX_DEPLOYMENT_TARGET matrix.runner rel/macos/build_otp.sh) do
        assert otp_key =~ part, "the OTP cache key does not include #{part}"
      end

      # OpenSSL inside crypto, and nothing the arbiter's Mac lacks.
      assert build_otp =~ "--disable-dynamic-ssl-lib"
      assert build_otp =~ "no-shared"
      assert build_otp =~ "--without-wx --without-javac --without-odbc"

      # Every version the workflow names has a checksum in the script.
      for var <- ~w(OTP_VERSION OPENSSL_VERSION ELIXIR_VERSION) do
        assert [_, version] = Regex.run(~r/^\s+#{var}: "([^"]+)"$/m, workflow)

        assert build_otp =~
                 ~r/^\s+#{Regex.escape(version)}(-otp-\d+)?\) \w+_sha256=[0-9a-f]{64} ;;$/m,
               "build_otp.sh has no checksum for #{var} #{version}"
      end

      # The SQLite NIF from source on the Mac, and never from a cache built
      # for another macOS.
      assert workflow =~ ~s(echo "EXQLITE_FORCE_BUILD=true" >> "$GITHUB_ENV")
      assert read("config/config.exs") =~ "config :exqlite, force_build: true"
      assert Regex.match?(~r/_build\/prod\/lib\n\s+key:.*env\.MACOSX_DEPLOYMENT_TARGET/, workflow)

      # A binary that wants newer than the target fails the build, by name;
      # the target defaults to the Apple Silicon one, and the Intel build
      # copies the Swift runtime into the app because 10.13 has none.
      assert build_app =~ "supported=${MACOSX_DEPLOYMENT_TARGET:-11.0}"
      assert build_app =~ "swift-stdlib-tool"
      assert build_otp =~ "darwin64-x86_64-cc"
      assert build_app =~ ~s(newer "$minos" "$supported")
      assert build_app =~ ~s(sed 's/^/  /' "$too_new")
    end
  end

  describe "the changelog" do
    test "has a section for this version, or says it is unreleased" do
      changelog = read("CHANGELOG.md")

      assert changelog =~ "\n## [#{version()}]" or changelog =~ "\n## [Unreleased]",
             "CHANGELOG.md says nothing about #{version()}"
    end

    @tag :tmp_dir
    test "release_notes.sh prints one version's section and nothing else", %{tmp_dir: dir} do
      if sh = System.find_executable("sh") do
        file = Path.join(dir, "CHANGELOG.md")

        File.write!(file, """
        # Changelog

        A version is released when it has a section (`## [0.2.0]`).

        ## [Unreleased]

        - [Feature] not yet

        ## [0.2.0] - 2026-11-03

        - [Feature] **The second.** With a `## [` in the middle of a line.
        - [Fix] And a fix.

        ## [0.1.0] - 2026-10-20

        - [Feature] The first.

        ## [0.1.5]
        """)

        script = Path.join(@root, "tools/release_notes.sh")

        assert {notes, 0} = System.cmd(sh, [script, "0.2.0", file])
        assert notes =~ "**The second.**"
        assert notes =~ "And a fix."
        refute notes =~ "The first."
        refute notes =~ "not yet"
        refute notes =~ "\n## ["
        assert String.starts_with?(notes, "- [Feature]")

        assert {first, 0} = System.cmd(sh, [script, "0.1.0", file])
        assert String.trim(first) == "- [Feature] The first."

        # No section, an empty section, and a version that only looks like
        # one that is there: nothing printed, and a failure.
        for missing <- ["0.3.0", "0.1.5", "0.2", "0.2.00"] do
          assert {"", 1} = System.cmd(sh, [script, missing, file])
        end
      end
    end
  end

  describe "the release" do
    test "is one release, with the files each system needs beside bin/" do
      release = Mix.Project.config()[:releases][:arkab]
      assert release[:applications] == [arkab: :permanent]

      for name <- ~w(arkab.sh install.sh update.sh uninstall.sh arkab.service
                     arkab-update.service arkab-update.path) do
        assert File.exists?(Path.join([@root, "rel/linux", name])), "rel/linux/#{name} is missing"
      end

      for name <- ~w(Arkab.bat launcher.c launcher.rc launcher.manifest Arkab.ico
                     build_launcher.ps1 build_installer.ps1) do
        assert File.exists?(Path.join([@root, "rel/windows", name])),
               "rel/windows/#{name} is missing"
      end

      for name <- ~w(Launcher.swift launcher.sh build_app.sh sign_and_notarize.sh Info.plist
                     entitlements.plist Arkab-icon.png) do
        assert File.exists?(Path.join([@root, "rel/macos", name])), "rel/macos/#{name} is missing"
      end

      # The plist takes its version from the release, never from a literal.
      plist = read("rel/macos/Info.plist")
      assert plist =~ "<string>__VERSION__</string>"
      refute plist =~ ~r{<key>CFBundleShortVersionString</key>\s*<string>\d}

      # The executable is the compiled Swift launcher; the script that
      # starts the server sits beside the release as a resource.
      build = read("rel/macos/build_app.sh")
      assert plist =~ ~r{<key>CFBundleExecutable</key>\s*<string>Arkab</string>}
      assert build =~ ~s(-o "$app/Contents/MacOS/Arkab" "$swift_source")
      assert build =~ ~s(-target "$swift_arch-apple-macos$supported")
      assert build =~ ~s(cp "$here/launcher.sh" "$app/Contents/Resources/launcher.sh")
      assert build =~ "logo=rel/macos/Arkab-icon.png"
    end

    test "the Mac app has a Dock icon, and a launcher that asks before it stops" do
      # LSUIElement hides the app from the Dock and Cmd-Tab.
      refute read("rel/macos/Info.plist") =~ "LSUIElement"

      swift = read("rel/macos/Launcher.swift")
      assert swift =~ ~s(let defaultDataFolder = "Library/Application Support/ArkabData")
      assert swift =~ ~s(let dataEnv = "ARKAB_DATA")
      assert swift =~ ~s(let releaseInResources = "app/bin/arkab")
      assert swift =~ ~s(let probePath = "/help")
      assert swift =~ "let askBeforeStopping = true"
      assert swift =~ ~s[appendingPathComponent("launcher.sh")]
      assert swift =~ ~s[contains("--headless")]
      assert read(".github/workflows/release.yml") =~ ~s("$launcher" --headless)

      imports = Regex.scan(~r/^import (\w+)$/m, swift, capture: :all_but_first)
      assert Enum.sort(List.flatten(imports)) == ["AppKit", "Foundation"]
    end

    test "a stop on the Mac reaches what the server started, not just the server" do
      sh = read("rel/macos/launcher.sh")
      # The tree is read before the BEAM goes, and all of it gets SIGKILL.
      assert sh =~ ~s[for child in $(pgrep -P "$1" 2>/dev/null)]
      assert sh =~ ~s[under=$(tree "$pid")]
      assert sh =~ "kill -KILL $under"
      # The app's own last resort takes the whole tree too, not the script alone.
      assert read("rel/macos/Launcher.swift") =~ "processTree(late.processIdentifier)"
    end

    test "a stop does not wait fifteen seconds for an open page, and says how it went" do
      # Bandit's default gives every open connection fifteen seconds at a
      # stop; the status page is always open somewhere.
      http = Application.fetch_env!(:arkab, ArkabWeb.Endpoint)[:http]
      assert http[:thousand_island_options][:shutdown_timeout] <= 3_000

      sh = read("rel/macos/launcher.sh")
      assert sh =~ "Stopping: the server stopped after"
      assert sh =~ "Stopping: still running after 20 seconds"
    end

    test "the Mac icon has Apple's margin around the tile" do
      png = File.read!(Path.join(@root, "rel/macos/Arkab-icon.png"))
      assert <<0x89, "PNG", _::binary-size(12), width::32, height::32, _::binary>> = png
      assert {width, height} == {1024, 1024}
    end

    test "the launcher and the program agree on the code that means \"update me\"" do
      assert read("rel/windows/launcher.c") =~
               "#define ARKAB_UPDATE_EXIT_CODE #{Updates.update_exit_code()}\n"
    end

    test "the unit runs the program as its own user, read-only but for the data" do
      unit = read("rel/linux/arkab.service")

      for line <- [
            "User=arkab",
            "SupplementaryGroups=dialout",
            "NoNewPrivileges=yes",
            "ProtectSystem=strict",
            "Restart=on-failure",
            "Environment=RELEASE_DISTRIBUTION=none",
            "Environment=ARKAB_UPDATER=systemd",
            "ExecStart=/opt/arkab/current/bin/arkab start"
          ] do
        assert unit =~ ~r/^#{Regex.escape(line)}$/m, "arkab.service lacks: #{line}"
      end

      # The boards are devices.
      refute unit =~ ~r/^PrivateDevices=/m
      refute unit =~ ~r/^User=root$/m
    end

    test "the shell scripts have Unix line endings, and the batch files Windows'" do
      for file <-
            Path.wildcard(Path.join(@root, "rel/linux/*")) ++
              Path.wildcard(Path.join(@root, "rel/macos/*.sh")) ++
              [Path.join(@root, "tools/release_notes.sh"), Path.join(@root, "rel/env.sh.eex")] do
        refute File.read!(file) =~ "\r", "#{file} has CRLF line endings"
      end
    end
  end

  describe "the Linux updater (rel/linux/update.sh)" do
    # `newer` is a plain function at the top of the script (the rest is in
    # main(), which must not run here), so it is cut out and run on its own.
    defp newer?(a, b) do
      script = read("rel/linux/update.sh")
      [function] = Regex.run(~r/^newer\(\) \{\n.*?\n\}\n/ms, script)

      {_out, status} =
        System.cmd("sh", ["-c", function <> ~s(\nnewer "$1" "$2"\n), "sh", a, b],
          stderr_to_stdout: true
        )

      status == 0
    end

    @tag :shell
    test "a requested version must be newer, number by number" do
      assert newer?("0.10.0", "0.9.0")
      assert newer?("1.0.0", "0.99.99")
      assert newer?("0.3.1", "0.3.0")
      refute newer?("0.3.0", "0.3.0")
      refute newer?("0.2.9", "0.3.0")
      refute newer?("0.9.0", "0.10.0")
    end

    test "a request for an older or equal version never reaches the download" do
      script = read("rel/linux/update.sh")
      [requested_block] = Regex.run(~r/if \[ "\$requested" = 1 \]; then.*?\n    fi\n/s, script)

      # The refusal comes before anything is fetched, and a missing installed
      # version is a refusal too.
      assert requested_block =~ "newer \"$wanted\" \"$current\""
      assert requested_block =~ ~s([ -z "$current" ])
      assert requested_block =~ "refused"
      refute requested_block =~ "curl"
      assert :binary.match(script, requested_block) < :binary.match(script, "curl -fsSL")
    end
  end
end
